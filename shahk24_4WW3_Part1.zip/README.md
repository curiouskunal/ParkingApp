# ParkingApp- Part 1

Name      : Kunal Shah

Mac ID    : shahk24
 
Student ID: 001419350


All unique cases commented once.

Read files in order:

index.html

parking.html

profile.html

register.html

results.html

search.html

submittion.html

main.css
parking.css
profile.css
results.css
search.css
submission.css
